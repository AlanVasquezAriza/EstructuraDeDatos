package grafo;

import java.util.ArrayList;

public interface Grafo <E>{
    void insVertice(E x);
    E obtVertice(int pos);
    void insArista(int vi, int vf, double costo);
    double costoArista(int vi, int vf);
    int orden();
    ArrayList<E> sucesores(int v);
    void mostrar();
    int inf = 0;
}
