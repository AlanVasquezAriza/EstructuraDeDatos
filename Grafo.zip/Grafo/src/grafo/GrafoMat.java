package grafo;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;

/**
 *
 * @author alanv
 * @param <E>
 */

public class GrafoMat<E> implements Grafo <E> {
    
    public double aristas [][] = new double[200][200];
    public ArrayList <E> vertices = new ArrayList<>();
    
    public GrafoMat(){
        for(int i = 0; i < aristas.length; i++){
            for(int j = 0; j < aristas[i].length; j++){
                if(i != j){ // Para que la diagonal principal no la afecte
                    aristas[i][j] = inf; 
                }
            }
        }
    }
    
    @Override
    public void insVertice(E x) {
        vertices.add(x); // Se agrega al array
    }

    @Override
    public E obtVertice(int pos) {
        if(valida(pos)){
            return vertices.get(pos);
        }
        return null;
    }

    @Override
    public void insArista(int vi, int vf, double costo) { // Asigna el costo de la arista
        if(valida(vi) && valida(vf)){
            aristas[vi][vf] = costo;
        }
    }

    @Override
    public double costoArista(int vi, int vf) { // Retorna el valor de la arista
        if(valida(vi) && valida(vf)){
            return aristas[vi][vf]; 
        }
        return -1; // En caso de que no halla un costo 
    }

    @Override
    public int orden() {
        return vertices.size();
    }

    @Override
    public ArrayList<E> sucesores(int v) {
        ArrayList<E> suc = new ArrayList<>();
        if(valida(v)){
            for(int i = 0; i < vertices.size(); i++){ // Recorremos la fila 
                if(aristas[v][i] != inf && i != v){ // Si valor difetente de infinito y de él mismo, colocamos en el array de sucesores
                    suc.add(obtVertice(i));
                }
            }
        }
        return suc;
    }

    @Override
    public void mostrar() {
        System.out.println(vertices);
        for(int i = 0; i < vertices.size(); i++){
            for(int j = 0; j < vertices.size(); j++){
                System.out.print( "  |  " + aristas[i][j] );
            }
            System.out.println("");
        }
    }
    
    private boolean valida(int vi){
        if(vi >= 0 && vi < orden()){
            return true;
        }
        return false;
    }
    
    public void floydWarshall() {
        int numVertices = orden();
        double[][] distancias = new double[numVertices][numVertices];

        // Inicializar la matriz de distancias con los costos de las aristas
        for (int i = 0; i < numVertices; i++) {
            for (int j = 0; j < numVertices; j++) {
                distancias[i][j] = costoArista(i, j);
            }
        }

        // Calcular todos los caminos más cortos
        for (int k = 0; k < numVertices; k++) {
            for (int i = 0; i < numVertices; i++) {
                for (int j = 0; j < numVertices; j++) {
                    if (distancias[i][k] + distancias[k][j] < distancias[i][j]) {
                        distancias[i][j] = distancias[i][k] + distancias[k][j];
                    }
                }
            }
        }

        for(int i = 0; i < distancias.length; i ++){
            for(int j = 0; j < distancias[i].length; j++){
                System.out.print("  |  " + distancias[i][j]);
            }
            System.out.println("");
        }
    }
    
    public GrafoMat<E> prim() {
        GrafoMat<E> arbolMin = new GrafoMat<E>();
        HashSet<Integer> visitados = new HashSet<Integer>();

        int numVertices = orden();
        if (numVertices <= 0) {
            return arbolMin;
        }

        // Elegir un vértice inicial (por ejemplo, el primer vértice)
        int verticeInicial = 0;
        visitados.add(verticeInicial);

        while (visitados.size() < numVertices) {
            double minCosto = Integer.MAX_VALUE;
            int origen = -1;
            int destino = -1;

            for (int v : visitados) {
                for (int u = 0; u < numVertices; u++) {
                    if (!visitados.contains(u) && costoArista(v, u) < minCosto) {
                        minCosto = costoArista(v, u);
                        origen = v;
                        destino = u;
                    }
                }
            }

            if (origen != -1 && destino != -1) {
                arbolMin.insVertice(obtVertice(origen));
                arbolMin.insVertice(obtVertice(destino));
                arbolMin.insArista(origen, destino, minCosto);
                visitados.add(destino);
            }
        }

        return arbolMin;
    }
    
    
    @Override
    // Dibujar el grafo
    // graphviz en visual studio code
    // crl + shift + ñ -> graphviz preview
    public void generarArchivoDOT(String filename) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            writer.write("graph GrafoMat {\n");

            // Escribir vértices
            for (int i = 0; i < vertices.size(); i++) {
                writer.write("  " + i + " [label=\"" + obtVertice(i) + "\"];\n");
            }

            // Escribir aristas
            for (int i = 0; i < aristas.length; i++) {
                for (int j = 0; j < aristas[i].length; j++) {
                    if (aristas[i][j] != inf && i != j) {
                        writer.write("  " + i + " -- " + j + " [label=\"" + aristas[i][j] + "\"];\n");
                    }
                }
            }

            writer.write("}\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }   
}
