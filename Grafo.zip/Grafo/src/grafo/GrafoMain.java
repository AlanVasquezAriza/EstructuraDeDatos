package grafo;
import javax.swing.JOptionPane;


public class GrafoMain {

     // Función para validar si una cadena es un número
    private static boolean isNumeric(String str) {
        try {
            Integer.parseInt(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
    
    public Grafo<String> crear(){
        
        Grafo<String> grafo = new GrafoMat<>();

        grafo.insVertice("UMB");  //0
        grafo.insVertice("P. sur");  //1
        grafo.insVertice("P. de las americas"); //2
        grafo.insVertice("P. 80"); //3
        grafo.insVertice("P. Norte");  //4
        grafo.insVertice("P. 20 de julio");  //5
        grafo.insVertice("P. el tunal");  //6
        grafo.insVertice("P. suba");  //7
        grafo.insVertice("P. Usme");  //8
        
        grafo.insArista(0, 1, 19.8);
        grafo.insArista(0, 2, 17.3);
        grafo.insArista(0, 3, 13.5);
        grafo.insArista(0, 4, 17.6);
        grafo.insArista(0, 5, 13.8);
        grafo.insArista(0, 6, 17.3);
        grafo.insArista(0, 7, 16.6);
        grafo.insArista(0, 8, 17.5);
        
        grafo.insArista(1, 2, 5.7);
        grafo.insArista(1, 3, 20.3);
        grafo.insArista(1, 4, 32.3);
        grafo.insArista(1, 5, 10.4);
        grafo.insArista(1, 6, 5.4);
        grafo.insArista(1, 7, 24);
        grafo.insArista(1, 8, 14.1);
        
        grafo.insArista(2, 1, 5.6);
        grafo.insArista(2, 3, 15.9);
        grafo.insArista(2, 4, 17.9);
        grafo.insArista(2, 5, 14.1);
        grafo.insArista(2, 6, 8.9);
        grafo.insArista(2, 7, 19);
        grafo.insArista(2, 8, 15.6);
        
        grafo.insArista(3, 1, 20.9);
        grafo.insArista(3, 2, 13.7);
        grafo.insArista(3, 4, 14.1);
        grafo.insArista(3, 5, 20.3);
        grafo.insArista(3, 6, 20.7);
        grafo.insArista(3, 7, 7.2);
        grafo.insArista(3, 8, 25.6);
        
        grafo.insArista(4, 1, 30.8);
        grafo.insArista(4, 2, 26.5);
        grafo.insArista(4, 3, 14.1);
        grafo.insArista(4, 5, 22.9);
        grafo.insArista(4, 6, 28);
        grafo.insArista(4, 7, 8.2);
        grafo.insArista(4, 8, 29);
        
        grafo.insArista(5, 1, 13.3);
        grafo.insArista(5, 2, 14);
        grafo.insArista(5, 3, 21.5);
        grafo.insArista(5, 4, 28.2);
        grafo.insArista(5, 6, 6.7);
        grafo.insArista(5, 7, 24.7);
        grafo.insArista(5, 8, 6.8);
         
        grafo.insArista(6, 1, 8.2);
        grafo.insArista(6, 2, 9.5);
        grafo.insArista(6, 3, 20.3);
        grafo.insArista(6, 4, 29.8);
        grafo.insArista(6, 5, 6);
        grafo.insArista(6, 7, 24);
        grafo.insArista(6, 8, 8.1);
        
        grafo.insArista(7, 1, 27);
        grafo.insArista(7, 2, 24);
        grafo.insArista(7, 3, 10);
        grafo.insArista(7, 4, 9);
        grafo.insArista(7, 5, 23);
        grafo.insArista(7, 6, 25);
        grafo.insArista(7, 8, 30);
        
        grafo.insArista(8, 1, 17);
        grafo.insArista(8, 2, 18);
        grafo.insArista(8, 3, 29);
        grafo.insArista(8, 4, 33);
        grafo.insArista(8, 5, 8);
        grafo.insArista(8, 6, 8);
        grafo.insArista(8, 7, 32);
        
        return grafo;
    }
    
    public static void main(String[] args){
        GrafoMain g = new GrafoMain();  
        Grafo<String> grafo = g.crear();
        int opcion;
        
        do {
            String menu = "Menú:\n"
                + "1. Mostrar\n"
                + "2. floydWarshall\n"
                + "3. Prim\n"
                + "4. Salir";

            String input = JOptionPane.showInputDialog(null, menu + "\nSeleccione una opción:");

            // Validar que el input sea un número
            if (isNumeric(input)) {
                opcion = Integer.parseInt(input);

                switch (opcion) {
                    case 1:
                        System.out.println("-------------------------------------------------------------------------------");
                        System.out.println("Grafo:");
                        System.out.println("-------------------------------------------------------------------------------");
                        
                        grafo.mostrar();
                        break;
                    case 2:
                        // Llamar al método floydWarshall
                        System.out.println("-------------------------------------------------------------------------------");
                        System.out.println("FloydWarshall:");
                        System.out.println("-------------------------------------------------------------------------------");
                        ((GrafoMat<String>) grafo).floydWarshall();
                        // Puedes hacer algo con la matriz de distancias si lo deseas
                        break;
                    case 3:
                        // Llamar al método prim
                        GrafoMat<String> arbolMinimo = ((GrafoMat<String>) grafo).prim();
                        System.out.println("-------------------------------------------------------------------------------");
                        System.out.println("Arbol de expansiOn mInima (Prim):");
                        System.out.println("-------------------------------------------------------------------------------");
                        arbolMinimo.mostrar();
                        break;
                    case 4:
                        System.out.println("Saliendo del programa. ¡Hasta luego!");
                        break;
                    default:
                        System.out.println("Opción no válida. Por favor, seleccione una opción válida.");
                        break;
                }
            } else {
                opcion = 0; // Establecer una opción inválida para continuar en el bucle
                JOptionPane.showMessageDialog(null, "Por favor, introduzca un número válido.");
            }
        } while (opcion != 4);
    }
}
