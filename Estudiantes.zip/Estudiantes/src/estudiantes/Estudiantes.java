package estudiantes;

public class Estudiantes {

    public static void main(String[] args) {
        NewJFrame pantalla = new NewJFrame();
        pantalla.setVisible(true);
        pantalla.setLocationRelativeTo(null);
    }
    
}
