package estudiantes;
import javax.swing.JOptionPane;

public class EstudianteObjeto {
    // Instancias
    String nombre = "";
    String apellido = "";
    String direccion = "";
    String carrera = "";
    int telefono = 0;
    
    // Constructor
    public EstudianteObjeto(){
        
        this.nombre = JOptionPane.showInputDialog("Ingrese el nombre del estudiante: ");
        this.apellido = JOptionPane.showInputDialog("Ingrese el apellido del estudiante: ");
        this.direccion = JOptionPane.showInputDialog("Ingrese la direccion del estudiante: ");
        this.carrera = JOptionPane.showInputDialog("Ingrese la carrera del estudiante: ");
                
        for (int i = 0; i < 10; i++) {
            // Pide la cantidad de marcas que se registraran
            String nS = JOptionPane.showInputDialog("Ingrese el telefono del estudiante: ");
    
            // Verificar que sea un numero
            if (nS != null && nS.matches("[0-9]+")) {
                this.telefono = Integer.parseInt(nS);
                break;
            }else{
                JOptionPane.showMessageDialog(null, "El dato digitado no es valido, por favor intentelo de nuevo");
                i--;
            }
        }
    }
    
    // Metodos
    
    public String getNombre(){
        return this.nombre;
    }
    public String getApellido(){
        return this.apellido;
    }
    public String getDireccion(){
        return this.direccion;
    }
    public String getCarrera(){
        return this.carrera;
    }
    public int getTelefono(){
        return this.telefono;
    }
    
    
    public void setNombre(String newNombre){
        this.nombre = newNombre;
    }
    public void setApellido(String newApellido){
        this.apellido = newApellido;
    }
    public void setDireccion(String newDireccion){
        this.direccion = newDireccion;
    }
    public void setCarrera(String newCarrera){
        this.carrera = newCarrera;
    }
    public void setTelefono(int newTelefono){
        this.telefono = newTelefono;
    }
    
}
