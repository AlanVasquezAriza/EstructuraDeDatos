package estudiantes;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import javax.swing.JOptionPane;

public class Metodos {
    // Instancias
    HashMap<Integer, Object> estudiantesLista = new HashMap<Integer, Object>();
    
    // Constructor
    public Metodos(){
        
    }
    
    // Metodos
    public void Ingresar(){
        
        int id = 0;
        
        for (int i = 0; i < 10; i++) {
            // Pide la cantidad de marcas que se registraran
            String idS = JOptionPane.showInputDialog("Ingrese el id del estudiante: ");
    
            // Verificar que sea un numero
            if (idS != null && idS.matches("[0-9]+")) {
                id = Integer.parseInt(idS);
                
                //Verifica que el ID no exista
                if(estudiantesLista.containsKey(id)){
                    JOptionPane.showMessageDialog(null,"El ID ya existe");
                    i--;
                }else{
                    break;
                }
                
            }else{
                JOptionPane.showMessageDialog(null, "El id digitado no es valido, por favor intentelo de nuevo");
                i--;
            }
        }
        
        estudiantesLista.put(id, new EstudianteObjeto());
        
    }
    
    public void Consultar(){ 
        
        int id = 0;
        
        for (int i = 0; i < 10; i++) {
            // Pide la cantidad de marcas que se registraran
            String idS = JOptionPane.showInputDialog("Ingrese el id del estudiante para buscar: ");
    
            // Verificar que sea un numero
            if (idS != null && idS.matches("[0-9]+")) {
                id = Integer.parseInt(idS);
                break;
            }else{
                JOptionPane.showMessageDialog(null, "El id digitado no es valido, por favor intentelo de nuevo");
                i--;
            }
        }
        
        if(estudiantesLista.containsKey(id)){
       
            Object objeto = estudiantesLista.get(id);
            String nombre = ((EstudianteObjeto)objeto).getNombre();
            String apellido = ((EstudianteObjeto)objeto).getApellido();
            String direccion = ((EstudianteObjeto)objeto).getDireccion();
            String carrera = ((EstudianteObjeto)objeto).getCarrera();
            int telefono = ((EstudianteObjeto)objeto).getTelefono();
            
            System.out.println("-------------------------------------------------------------------------------------------------------------------------");
            System.out.println("Resultados de las busquedas:");
            System.out.printf("%-20s\t| %-20s\t| %-20s\t| %-20s\t| %-20s%n", "Nombre", "Apellido", "Direccion", "Carrera", "Telefono" );
            System.out.println("-------------------------------------------------------------------------------------------------------------------------");
            System.out.printf("%-20s\t| %-20s\t| %-20s\t| %-20s\t| %-20d%n", nombre, apellido, direccion, carrera, telefono);
            
        }   
        else{
            JOptionPane.showMessageDialog(null, "No se han encontrado coincidencias");
        }
        
        
    }
    
    public void Modificar(){
        
        int id = 0;
        
        for (int i = 0; i < 10; i++) {
            // Pide la cantidad de marcas que se registraran
            String idS = JOptionPane.showInputDialog("Ingrese el id del estudiante para buscar: ");
    
            // Verificar que sea un numero
            if (idS != null && idS.matches("[0-9]+")) {
                id = Integer.parseInt(idS);
                break;
            }else{
                JOptionPane.showMessageDialog(null, "El id digitado no es valido, por favor intentelo de nuevo");
                i--;
            }
        }
        
        if(estudiantesLista.containsKey(id)){
       
            Object objeto = estudiantesLista.get(id);
            String nombre = ((EstudianteObjeto)objeto).getNombre();
            String apellido = ((EstudianteObjeto)objeto).getApellido();
            String direccion = ((EstudianteObjeto)objeto).getDireccion();
            String carrera = ((EstudianteObjeto)objeto).getCarrera();
            int telefono = ((EstudianteObjeto)objeto).getTelefono();
            
            System.out.println("-------------------------------------------------------------------------------------------------------------------------");
            System.out.println("Resultados de las busquedas:");
            System.out.printf("%-20s\t| %-20s\t| %-20s\t| %-20s\t| %-20s%n", "Nombre", "Apellido", "Direccion", "Carrera", "Telefono" );
            System.out.println("-------------------------------------------------------------------------------------------------------------------------");
            System.out.printf("%-20s\t| %-20s\t| %-20s\t| %-20s\t| %-20d%n", nombre, apellido, direccion, carrera, telefono);
            
        }   
        else{
            JOptionPane.showMessageDialog(null,"No se han encontrado coincidencias");
        }
        
        estudiantesLista.put(id, new EstudianteObjeto());
        
    }
    
    public void Eliminar(){
        
        int id = 0;
        
        for (int i = 0; i < 10; i++) {
            // Pide la cantidad de marcas que se registraran
            String idS = JOptionPane.showInputDialog("Ingrese el id del estudiante para buscar: ");
    
            // Verificar que sea un numero
            if (idS != null && idS.matches("[0-9]+")) {
                id = Integer.parseInt(idS);
                break;
            }else{
                JOptionPane.showMessageDialog(null, "El id digitado no es valido, por favor intentelo de nuevo");
                i--;
            }
        }
        
        estudiantesLista.remove(id);
        
    }
    
    public void Lista(){
        System.out.println("-------------------------------------------------------------------------------------------------------------------------");
        System.out.println("Resultados de las busquedas:");
        System.out.printf("%-16s\t| %-16s\t| %-16s\t| %-16s\t| %-16s\t| %-16s%n", "ID", "Nombre", "Apellido", "Direccion", "Carrera", "Telefono" );
        System.out.println("-------------------------------------------------------------------------------------------------------------------------");
                
        for (Map.Entry<Integer, Object> entry : estudiantesLista.entrySet()) {
            Integer key = entry.getKey();
            Object objeto = entry.getValue();
            
            String nombre = ((EstudianteObjeto)objeto).getNombre();
            String apellido = ((EstudianteObjeto)objeto).getApellido();
            String direccion = ((EstudianteObjeto)objeto).getDireccion();
            String carrera = ((EstudianteObjeto)objeto).getCarrera();
            int telefono = ((EstudianteObjeto)objeto).getTelefono();
            
            System.out.printf("%-16d\t| %-16s\t| %-16s\t| %-16s\t| %-16s\t| %-16d%n", key, nombre, apellido, direccion, carrera, telefono);
            
            
        }
    }
    
}