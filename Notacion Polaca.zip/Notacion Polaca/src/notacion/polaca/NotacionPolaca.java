package notacion.polaca;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class NotacionPolaca {
    
    // Creamos una pila con List y ArrayList
    static class Pila<T> {
        private List<T> elementos;

        public Pila() {
            elementos = new ArrayList<>();
        }

        public void push(T elemento) {
            elementos.add(elemento);
        }

        public T pop() {
            if (isEmpty()) {
                throw new IllegalStateException("La pila está vacía");
            }
            T elemento = elementos.get(size() - 1);
            elementos.remove(size() - 1);
            return elemento;
        }

        public T peek() {
            if (isEmpty()) {
                throw new IllegalStateException("La pila está vacía");
            }
            return elementos.get(size() - 1);
        }

        public int size() {
            return elementos.size();
        }

        public boolean isEmpty() {
            return elementos.isEmpty();
        }
    }

    
    // Verifica que la expresion este balanceada
    public static boolean estaBalanceada(String expresion) {
        Pila<Character> pila = new Pila<>();
        for (char c : expresion.toCharArray()) {
            // Si el carácter es un paréntesis de apertura '(' o '[' (como '(' )
            if (c == '(' || c == '[') {
                pila.push(c);
            // Si el carácter es un paréntesis de cierre ')' o ']' (como ')'), 
            // se verifica si la pila está vacía. Si está vacía, significa que no hay un paréntesis o 
            // corchete abierto correspondiente, por lo que la expresión no está balanceada. 
            } else if (c == ')' || c == ']') {
                if (pila.isEmpty()) {
                    return false;
                }
                char top = pila.pop();
                // Verifica si los de apertura se cerraron
                if ((c == ')' && top != '(') || (c == ']' && top != '[')) {
                    return false;
                }
            }
        }
        return pila.isEmpty();
    }
    
    
    public static int prioridad(char operador) {
        if (operador == '+' || operador == '-') {
            return 1;
        } else if (operador == '*' || operador == '/') {
            return 2;
        }
        return 0;
    }

    
    public static String convertirAPostfija(String expresion) {
        
        StringBuilder resultado = new StringBuilder();
        Pila<Character> operadores = new Pila<>();

        for (char c : expresion.toCharArray()) {
            if (Character.isDigit(c) || Character.isLetter(c)) {
                resultado.append(c);  // Agregar operandos directamente al resultado.
                
            } else if (c == '(' || c == '[') {
                operadores.push(c);  // Si es un paréntesis o corchete de apertura, lo ponemos en la pila de operadores.
                
            } else if (c == ')' || c == ']') {
                // Cuando encontramos un paréntesis o corchete de cierre, desapilamos operadores hasta encontrar el correspondiente de apertura.
                
                while (!operadores.isEmpty() && operadores.peek() != '(' && operadores.peek() != '[') {
                    resultado.append(operadores.pop());  // Agregar operadores a la salida.
                }
                
                operadores.pop();  // Eliminar el paréntesis o corchete de apertura de la pila.
                
            } else {
                // Si encontramos un operador, verificamos la prioridad y desapilamos los operadores de mayor o igual prioridad.
                
                while (!operadores.isEmpty() && prioridad(operadores.peek()) >= prioridad(c)) {
                    
                    resultado.append(operadores.pop());  // Agregar operadores a la salida.
                    
                }
                operadores.push(c);  // Poner el operador en la pila.
            }
        }

        // Después de procesar toda la expresión, desapilamos cualquier operador restante y lo agregamos a la salida.
        while (!operadores.isEmpty()) {
            resultado.append(operadores.pop());
        }

        return resultado.toString();  // La cadena de resultado es la expresión en notación postfija.
    }


    public static double resolverPostfija(String expresion) {
        
        Pila<Double> stack = new Pila<>();

        for (char c : expresion.toCharArray()) {
            if (Character.isDigit(c)) {
                stack.push((double) (c - '0')); // Convertir el dígito a un número y apilarlo.
            } else {
                double operand2 = stack.pop();  // Desapilar el segundo operando.
                double operand1 = stack.pop();  // Desapilar el primer operando.

                // Realizar la operación según el operador y apilar el resultado.
                switch (c) {
                    case '+':
                        stack.push(operand1 + operand2);
                        break;
                    case '-':
                        stack.push(operand1 - operand2);
                        break;
                    case '*':
                        stack.push(operand1 * operand2);
                        break;
                    case '/':
                        stack.push(operand1 / operand2);
                        break;
                }
            }
        }
        return stack.pop(); // El resultado final en la pila es el resultado de la expresión.
    }


    public static void main(String[] args) {
        
        NewJFrame pantalla = new NewJFrame();
        pantalla.setVisible(true);
        pantalla.setLocationRelativeTo(null);
    }
}

