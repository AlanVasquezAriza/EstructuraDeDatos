import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class Nodo {
    int num;
    Nodo hijoIzquierdo, hijoDerecho;

    public Nodo(int num) {
        this.num = num;
        hijoIzquierdo = null;
        hijoDerecho = null;
    }
}

class ArbolBinario {
    private Nodo raiz;

    public ArbolBinario() {
        raiz = null;
    }

    public Nodo getRaiz() {
        return raiz;
    }

    public void insertarNodo(int num) {
        raiz = insertarRec(raiz, num);
    }

    private Nodo insertarRec(Nodo raiz, int num) {
        if (raiz == null) {
            raiz = new Nodo(num);
            return raiz;
        }

        if (num < raiz.num) {
            raiz.hijoIzquierdo = insertarRec(raiz.hijoIzquierdo, num);
        } else if (num > raiz.num) {
            raiz.hijoDerecho = insertarRec(raiz.hijoDerecho, num);
        }

        return raiz;
    }

    public void eliminarNodo(int num) {
        raiz = eliminarRec(raiz, num);
    }

    private Nodo eliminarRec(Nodo raiz, int num) {
        if (raiz == null) {
            return raiz;
        }

        if (num < raiz.num) {
            raiz.hijoIzquierdo = eliminarRec(raiz.hijoIzquierdo, num);
        } else if (num > raiz.num) {
            raiz.hijoDerecho = eliminarRec(raiz.hijoDerecho, num);
        } else {
            if (raiz.hijoIzquierdo == null) {
                return raiz.hijoDerecho;
            } else if (raiz.hijoDerecho == null) {
                return raiz.hijoIzquierdo;
            }

            raiz.num = minValorNodo(raiz.hijoDerecho);

            raiz.hijoDerecho = eliminarRec(raiz.hijoDerecho, raiz.num);
        }

        return raiz;
    }

    private int minValorNodo(Nodo nodo) {
        int minValor = nodo.num;
        while (nodo.hijoIzquierdo != null) {
            minValor = nodo.hijoIzquierdo.num;
            nodo = nodo.hijoIzquierdo;
        }
        return minValor;
    }

    public Nodo buscarNodo(int num) {
        return buscarRec(raiz, num);
    }

    private Nodo buscarRec(Nodo raiz, int num) {
        if (raiz == null || raiz.num == num) {
            return raiz;
        }

        if (raiz.num > num) {
            return buscarRec(raiz.hijoIzquierdo, num);
        }

        return buscarRec(raiz.hijoDerecho, num);
    }

    // Recorrido In-Orden
    public void recorrerInOrden(Nodo raiz) {
        if (raiz != null) {
            recorrerInOrden(raiz.hijoIzquierdo);
            System.out.print(raiz.num + " ");
            recorrerInOrden(raiz.hijoDerecho);
        }
    }

    // Recorrido Preorden
    public void recorrerPreOrden(Nodo raiz) {
        if (raiz != null) {
            System.out.print(raiz.num + " ");
            recorrerPreOrden(raiz.hijoIzquierdo);
            recorrerPreOrden(raiz.hijoDerecho);
        }
    }

    // Recorrido Postorden
    public void recorrerPostOrden(Nodo raiz) {
        if (raiz != null) {
            recorrerPostOrden(raiz.hijoIzquierdo);
            recorrerPostOrden(raiz.hijoDerecho);
            System.out.print(raiz.num + " ");
        }
    }
}

public class ArbolBinarioGrafico extends JFrame {
    private JPanel ventana;
    private ArbolBinario arbol = new ArbolBinario();

    private JTextField nodoTextField;
    private JButton insertarButton;
    private JButton eliminarButton;
    private JTextField nodoBuscarTextField;
    private JButton buscarButton;
    private JButton inOrdenButton;
    private JButton preOrdenButton;
    private JButton postOrdenButton;
    private JPanel dibujoPanel;

    public ArbolBinarioGrafico() {
        super("Árbol binario gráfico");
        ventana = new JPanel();
        ventana.setLayout(new FlowLayout());

        nodoTextField = new JTextField(10);
        insertarButton = new JButton("Insertar Nodo");
        eliminarButton = new JButton("Eliminar Nodo");
        nodoBuscarTextField = new JTextField(10);
        buscarButton = new JButton("Buscar Nodo");
        inOrdenButton = new JButton("In-Orden");
        preOrdenButton = new JButton("Pre-Orden");
        postOrdenButton = new JButton("Post-Orden");
        dibujoPanel = new JPanel();

        ventana.add(nodoTextField);
        ventana.add(insertarButton);
        ventana.add(eliminarButton);
        ventana.add(nodoBuscarTextField);
        ventana.add(buscarButton);
        ventana.add(inOrdenButton);
        ventana.add(preOrdenButton);
        ventana.add(postOrdenButton);
        add(ventana, BorderLayout.NORTH);
        add(dibujoPanel, BorderLayout.CENTER);

        insertarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String valor = nodoTextField.getText();
                if (!valor.isEmpty()) {
                    int num = Integer.parseInt(valor);
                    arbol.insertarNodo(num);
                    repaint();
                }
                nodoTextField.setText("");
            }
        });

        eliminarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String valor = nodoTextField.getText();
                if (!valor.isEmpty()) {
                    int num = Integer.parseInt(valor);
                    arbol.eliminarNodo(num);
                    repaint();
                }
                nodoTextField.setText("");
            }
        });

        buscarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String valor = nodoBuscarTextField.getText();
                if (!valor.isEmpty()) {
                    int num = Integer.parseInt(valor);
                    Nodo nodoBuscado = arbol.buscarNodo(num);
                    if (nodoBuscado != null) {
                        JOptionPane.showMessageDialog(null, "Nodo encontrado: " + num, "Búsqueda Exitosa", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "Nodo no encontrado: " + num, "Búsqueda Fallida", JOptionPane.ERROR_MESSAGE);
                    }
                }
                nodoBuscarTextField.setText("");
            }
        });

            inOrdenButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.print("Recorrido In-Orden: ");
            arbol.recorrerInOrden(arbol.getRaiz());
            System.out.println();
        }
    });

    preOrdenButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.print("Recorrido Pre-Orden: ");
            arbol.recorrerPreOrden(arbol.getRaiz());
            System.out.println();
        }
    });

    postOrdenButton.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            System.out.print("Recorrido Post-Orden: ");
            arbol.recorrerPostOrden(arbol.getRaiz());
            System.out.println();
        }
    });
}

public void paint(Graphics g) {
    super.paint(g);
    dibujarArbol(g, arbol.getRaiz(), getWidth() / 2, 50, getWidth() / 4);
}

private void dibujarArbol(Graphics g, Nodo nodo, int x, int y, int espacio) {
    if (nodo != null) {
        g.setColor(Color.black);
        g.fillOval(x, y, 30, 30);
        g.setColor(Color.white);
        g.drawString(Integer.toString(nodo.num), x + 12, y + 20);

        if (nodo.hijoIzquierdo != null) {
            g.setColor(Color.black);
            g.drawLine(x + 15, y + 30, x - espacio + 15, y + 80);
            dibujarArbol(g, nodo.hijoIzquierdo, x - espacio, y + 80, espacio / 2);
        }
        if (nodo.hijoDerecho != null) {
            g.setColor(Color.black);
            g.drawLine(x + 15, y + 30, x + espacio + 15, y + 80);
            dibujarArbol(g, nodo.hijoDerecho, x + espacio, y + 80, espacio / 2);
        }
    }
}

public static void main(String[] args) {
    SwingUtilities.invokeLater(new Runnable() {
        @Override
        public void run() {
            ArbolBinarioGrafico ventana;
            ventana = new ArbolBinarioGrafico();
            ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            ventana.setSize(800, 600);
            ventana.setVisible(true);
        }
    });
  }
} 